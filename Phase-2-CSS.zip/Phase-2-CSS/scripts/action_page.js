function sendFakeEmail() {
  alert("Sent Email Succesfully");
}
function makeFakeFilter() {
  alert("Data Filtered");
}
